import React, { useState, useEffect } from "react";
import { User, WarReasonSubmission, GeminiLog } from "../types";
import { Settings, ShieldCheck, HelpCircle, Save, Megaphone, Terminal, FileCode, CheckCircle, RefreshCw } from "lucide-react";

interface AdminPanelProps {
  user: User;
  wars: WarReasonSubmission[];
  prices: { oil: number; steel: number; food: number };
  onAdminUpdatePrices: (oil: number, steel: number, food: number) => void;
  onAdminOverrideWar: (warId: string, status: string) => void;
  onAdminBroadcast: (text: string) => void;
  onFetchLogs: () => Promise<GeminiLog[]>;
}

export default function AdminPanel({
  user,
  wars,
  prices,
  onAdminUpdatePrices,
  onAdminOverrideWar,
  onAdminBroadcast,
  onFetchLogs
}: AdminPanelProps) {
  const [broadcastText, setBroadcastText] = useState("");
  const [oilPrice, setOilPrice] = useState(prices.oil.toString());
  const [steelPrice, setSteelPrice] = useState(prices.steel.toString());
  const [foodPrice, setFoodPrice] = useState(prices.food.toString());

  const [aiLogs, setAiLogs] = useState<GeminiLog[]>([]);
  const [isLogsLoading, setIsLogsLoading] = useState(false);

  const loadLogs = async () => {
    setIsLogsLoading(true);
    try {
      const logs = await onFetchLogs();
      setAiLogs(logs);
    } catch {
      // handled
    } finally {
      setIsLogsLoading(false);
    }
  };

  useEffect(() => {
    loadLogs();
  }, []);

  const handleBroadcastSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!broadcastText) return;
    onAdminBroadcast(broadcastText);
    setBroadcastText("");
    alert("خبرنامه با موفقیت ثبت پیجر بین‌المللی مجمع شد!");
  };

  const handlePriceUpdate = (e: React.FormEvent) => {
    e.preventDefault();
    onAdminUpdatePrices(
      parseFloat(oilPrice) || 12,
      parseFloat(steelPrice) || 18,
      parseFloat(foodPrice) || 7
    );
    alert("قیمت‌های بورس اصلاح شد!");
  };

  return (
    <div className="space-y-6">
      {/* Upper header */}
      <div className="rounded-2xl border border-rose-500/10 bg-rose-950/5 p-6">
        <h2 className="text-lg font-bold text-rose-300 flex items-center gap-1.5">
          <ShieldCheck className="h-6 w-6 text-rose-400" /> میز فرماندهی نظارت و رهبری کلان (پنل مدیریت بازی)
        </h2>
        <p className="text-slate-400 text-xs mt-1">تسهیلات نظارتی اختصاصی جهت اصلاح بورس کالا، مانیتورینگ زنده تماس‌های جمینی، ابلاغ جریمه‌ها و مهار تحرکات خشن نظامی.</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        
        {/* RESOURCE PRICING CONTROLS */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-6 space-y-4">
          <h2 className="text-sm font-bold text-slate-200">📊 مداخله دستی در نرخ قیمت ارزهای بورس</h2>
          <form onSubmit={handlePriceUpdate} className="space-y-3.5 text-xs text-right">
            <div className="grid grid-cols-3 gap-3">
              <div>
                <label className="text-slate-400 block mb-1">قیمت نفت (طلا)</label>
                <input type="number" step="0.1" value={oilPrice} onChange={(e) => setOilPrice(e.target.value)} className="w-full bg-slate-950 p-2 rounded text-white border border-slate-800" />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">قیمت فولاد (طلا)</label>
                <input type="number" step="0.1" value={steelPrice} onChange={(e) => setSteelPrice(e.target.value)} className="w-full bg-slate-950 p-2 rounded text-white border border-slate-800" />
              </div>
              <div>
                <label className="text-slate-400 block mb-1">قیمت گندم (طلا)</label>
                <input type="number" step="0.1" value={foodPrice} onChange={(e) => setFoodPrice(e.target.value)} className="w-full bg-slate-950 p-2 rounded text-white border border-slate-800" />
              </div>
            </div>

            <button type="submit" className="w-full py-2 bg-rose-600 hover:bg-rose-500 text-white font-bold rounded shadow transition flex justify-center items-center gap-1">
              <Save className="h-3.5 w-3.5" /> ذخیره قیمت‌های مصوب جدید
            </button>
          </form>
        </div>

        {/* BROADCAST SERVICE */}
        <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-6 space-y-4">
          <h2 className="text-sm font-bold text-slate-200">📣 اعلام بیانیه‌های حاکمیتی و اخطارهای فوری</h2>
          <form onSubmit={handleBroadcastSubmit} className="space-y-3">
            <textarea
              placeholder="مثال: با توجه به کمبود آذوقه جهانی، جریمه‌های مالیاتی متخلفین گران‌فروش دو برابر گردید..."
              value={broadcastText}
              onChange={(e) => setBroadcastText(e.target.value)}
              className="w-full text-xs text-white bg-slate-950 p-2 rounded border border-slate-800 focus:outline-none focus:border-rose-500"
              rows={2}
            />
            <button type="submit" className="w-full py-2 bg-indigo-600 hover:bg-indigo-500 text-white text-xs font-bold rounded transition flex justify-center items-center gap-1">
              <Megaphone className="h-3.5 w-3.5" /> پرتاب خبر به پیجر متحرک ملل
            </button>
          </form>
        </div>

      </div>

      {/* WAR CONTROL AND OVERRIDES */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-6 space-y-4">
        <h2 className="text-sm font-bold text-slate-200">⚔️ نظارت زنده بر روند جنگ‌ها و ابطال دستی وضعیت‌ها</h2>
        {wars.length === 0 ? (
          <p className="text-slate-500 text-xs text-center py-6">هیچ منازعه فعالی تحت نظارت به ثبت نرسیده است.</p>
        ) : (
          <div className="space-y-3">
            {wars.map((war) => (
              <div key={war.id} className="rounded-xl bg-slate-950/45 p-3.5 border border-slate-900 text-xs flex flex-col sm:flex-row justify-between items-start sm:items-center gap-3">
                <div>
                  <p className="font-bold text-slate-200">{war.attackerCountry} مبارزه با {war.defenderCountry}</p>
                  <p className="text-slate-400 text-[10px] truncate max-w-lg mt-1 italic">علت: « {war.casusBelli || "علت جنگ نامعلوم"} »</p>
                  <p className="text-[10px] text-slate-500 font-mono mt-1">تعداد رندهای نبرد: {war.rounds.length}  | وضعیت پرونده: {war.status}</p>
                </div>

                {war.status !== "ended" && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => onAdminOverrideWar(war.id, "ended")}
                      className="bg-red-900/20 text-red-500 hover:bg-slate-900 border border-red-900/30 px-3 py-1 rounded text-[10px] font-bold"
                    >
                      صلح زوری ادمین (پایان جنگ) 🕊️
                    </button>
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* LIVE AI API REQUESTS LOGGER DETAILS */}
      <div className="rounded-2xl border border-slate-800 bg-slate-900/40 p-6 space-y-4">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-slate-200 flex items-center gap-1.5">
            <Terminal className="h-5 w-5 text-indigo-400" /> پایش زنده تمام لاگ‌های درخواست‌ها و پرداختهای هوش مصنوعی جمینی
          </h2>
          <button
            onClick={loadLogs}
            disabled={isLogsLoading}
            className="flex items-center gap-1 rounded border border-slate-800 px-3 py-1 text-[10px] text-slate-400 bg-slate-950/50 hover:bg-slate-900 transition"
          >
            <RefreshCw className={`h-3 w-3 ${isLogsLoading ? 'animate-spin' : ''}`} /> بروزرسانی لاگ‌ها
          </button>
        </div>

        {aiLogs.length === 0 ? (
          <p className="text-slate-500 text-xs text-center py-8 border border-dashed border-slate-800 rounded-xl bg-slate-950/10">هیچ پرسشی از جمینی به ثبت نرسیده است.</p>
        ) : (
          <div className="space-y-4 max-h-96 overflow-y-auto pr-1">
            {aiLogs.map((log) => (
              <div key={log.id} className="rounded-xl bg-slate-950 p-4 border border-slate-900 text-xs space-y-2 font-mono">
                <div className="flex justify-between text-[10px] text-slate-500">
                  <span>شناسه تراکنش: {log.id}</span>
                  <span>زمان پایش: {new Date(log.timestamp).toLocaleTimeString('fa-IR')}</span>
                </div>
                
                <div className="bg-slate-900/50 p-2.5 rounded text-[11px] space-y-1">
                  <span className="text-blue-400 block font-bold">● پرامپت ارسالی ادمین:</span>
                  <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">{log.prompt}</p>
                </div>

                <div className="bg-slate-900/50 p-2.5 rounded text-[11px] space-y-1">
                  <span className={`block font-bold ${log.error ? 'text-red-400' : 'text-emerald-400'}`}>
                    ● پاسخ نهایی جمینی:
                  </span>
                  <p className="text-slate-300 leading-relaxed whitespace-pre-wrap">
                    {log.error ? `خطا: ${log.error}` : log.response}
                  </p>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

    </div>
  );
}
